var score = 0;
var audioPlayer = document.getElementById("audio");

//Array-variable with all the questions
var questions = [
	["Vem är Finlands president?"],
	["Vad är Finlands huvudstad?"],
	["I vilket landskap ligger Ekenäs?"]
];

//Array-variable with all the answers
var answers = [
	["Tarja Halonen"],
	["Sauli Niinistö"],
	["Jukka Korpisalo"],
	["Åbo"],
	["Karis"],
	["Helsingfors"],
	["Åboland"],
	["Päijät-Häme"],
	["Nyland"],
];

var resultMessage = [
	["Du är värdelös"],
	["Bättre kan du"],
	["Wow, Einstein!"],
];

function startGame(){
	document.getElementById("startMenu").style.display = "none";
	document.getElementById("questionArea").style.display = "block";

}

function nextQuestion(quest, ans1, ans2, ans3) {
	document.getElementById('question'). innerHTML = quest;
	document.getElementById('answer1'). innerHTML = ans1;
	document.getElementById('answer2'). innerHTML = ans2;
	document.getElementById('answer3'). innerHTML = ans3;

}

function userAnswer(answerNr){
	if(questionNr == 0 && answerNr == 2 ||
		questionNr == 1 && answerNr == 3 ||
		questionNr == 2 && answerNr == 3){
		score++;
		audioPlayer.src = "sound/success.mp3";
		audioPlayer.play();
		document.getElementById("scoreBox").innerHTML = "Du har "+score+ " poäng";
		changeQuestion();
	}
	else {
		score--;
		audioPlayer.src = "sound/fail.mp3";
		audioPlayer.play();
		document.getElementById("scoreBox").innerHTML = "Du har "+score+ " poäng";
		changeQuestion();
	}

	if (questionNr == 3){
		document.getElementById("questionArea").style.display = "none";
		document.getElementById("scoreResult").style.display = "block";

		var scoreGrade;
		if(score <=1){scoreGrade = 0;}
		if(score > 1 && score <=2){scoreGrade = 1;}
		if(score > 2 && score <=3){scoreGrade = 2;}
		document.getElementById("endGame").style.display = "block";
		document.getElementById("scoreResult").innerHTML = resultMessage[scoreGrade];
		document.getElementById("reload").style.display = "block";
	}
}

//Function that changes the question and answer alternatives
var questionNr = 0;
var answerNumber = 0;

function changeQuestion(){
questionNr++;
answerNumber+=3;
nextQuestion(questions[questionNr], answers[answerNumber], answers[answerNumber+1], answers[answerNumber+2]);
}

//Executes function at document load
nextQuestion(questions[0], answers[0],answers[1],answers[2]);

//Refreshes page
function restartGame() {
	location.reload();
}